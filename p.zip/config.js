module.exports = {
  BOT_TOKEN: "7540920655:AAHbAEj8u_UyK6Jc8dq8QGjggPtwkGfUqHc", // Token bot Telegram
  OWNER_ID: "6810074747", // ID pemilik bot
  allowedGroupIds: [-1002401306074, -1002361556670, -1002386380830, -1002415460020, -4514397992], // ID grup yang diizinkan
};